=== Like Dislike Counter===
Contributors: tikendramaitry, rahulbrilliant2004, Nishant Jain
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=wpfruits@gmail.com&item_name=Like%20Dislike%20Counter%20Lite&item_number=WordPress.org%20Donation&currency_code=USD&lc=US
Tags: like counter, dislike counter,like, dislike, most liked posts and comments, recently liked posts and comments, thumbs down, thumbs up, like dislike page, like dislike post, like dislike comments
Requires at least: 3.0
Tested up to: 3.9
Stable tag: 1.2.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A simple ajax based WordPress Plugin which allows you to like or dislike posts, pages and comments and shows the like dislike counter as well.   

== Description ==

Like Dislike counter plugin allows to integrate Like, Dislike Button into your WordPress website to allow your visitors to like and dislike pages, posts, custom post types and comments anonymously. Its very simple to use. Users even don't have to write a single line of code to setup this plugin. It counts unique likes/dislikes for post/pages/comments. 

**PRO Plugin URL: <a href="http://www.sketchthemes.com/plugins/like-dislike-counter-pro-wordpress-plugin/
" target="_blank">Like Dislike Pro Plugin Url</a>**

**PRO Plugin Demo URL: <a href="http://plugins.wpfruits.com/like-dislike/
" target="_blank">Like Dislike Pro Demo</a>**

**Go PRO: <a href="http://www.sketchthemes.com/members/signup.php?price_group=8&product_id=8&hide_paysys=paypal_r&ref=wp_org
" target="_blank">Like Dislike Go Pro</a>**

= Pro Features =
* Great Interface.
* Ajax feature to update the data without reloading.
* Visitors do not have to register or log in to use the Like Button.
* Like-Dislike on Page, Post, Archive Pages and Comments.
* Like Dislike count for Page, Post, Archive Pages and Comments.
* Compatible with WP version 3.0 & above.
* Easy Backend.
* Clean Design.
* Compatible with Multisite.
* Added automatically (no Code required).
* Template code ready.
* Custom Like-Dislike Texts.
* No Back Link needed.
* Widget to show 'Most Liked' & generate more traffic.<a href="http://www.sketchthemes.com/plugins/like-dislike-counter-pro-wordpress-plugin/
" target="_blank">(Pro Version)</a>
* 10 pre-designed Templates.<a href="http://www.sketchthemes.com/plugins/like-dislike-counter-pro-wordpress-plugin/
" target="_blank">(Pro Version)</a>
* Freedom to Upload Custom Icon Set.<a href="http://www.sketchthemes.com/plugins/like-dislike-counter-pro-wordpress-plugin/
" target="_blank">(Pro Version)</a>
* Different Appearance Settings for Comments & Pages.<a href="http://www.sketchthemes.com/plugins/like-dislike-counter-pro-wordpress-plugin/
" target="_blank">(Pro Version)</a>
* 24 x 7 Premium Support.<a href="http://www.sketchthemes.com/plugins/like-dislike-counter-pro-wordpress-plugin/
" target="_blank">(Pro Version)</a>
* Shortcode to show like dislike buttons within content.<a href="http://www.sketchthemes.com/plugins/like-dislike-counter-pro-wordpress-plugin/
" target="_blank">(Pro Version)</a>
* Enable/Disable for Post Page, Archive Pages(Tags,Authors,Category,Date etc.) and Comments.(Pro Version)
* Display different iconts for Post/Page and Comments.<a href="http://www.sketchthemes.com/plugins/like-dislike-counter-pro-wordpress-plugin/
" target="_blank">(Pro Version)</a>

**PRO Plugin URL: <a href="http://www.sketchthemes.com/plugins/like-dislike-counter-pro-wordpress-plugin/
" target="_blank">Like Dislike Pro Plugin Url</a>**

**PRO Plugin Demo URL: <a href="http://plugins.wpfruits.com/like-dislike/
" target="_blank">Like Dislike Pro Demo</a>**

== Features ==
* Great Interface.
* Ajax feature to update the data without reloading.
* Visitors do not have to register or log in to use the Like Button.
* Like-Dislike on Page, Post, Archive Pages and Comments.
* Like Dislike count for Page, Post, Archive Pages and Comments.
* Compatible with WP version 3.0 & above.
* Easy Backend.
* Clean Design.
* Compatible with Multisite.
* Added automatically (no Code required).
* Template code ready.
* Custom Like-Dislike Texts.
* No Back Link needed.
* Widget to show 'Most Liked' & generate more traffic.<a href="http://www.sketchthemes.com/plugins/like-dislike-counter-pro-wordpress-plugin/
" target="_blank">(Pro Version)</a>
* 10 pre-designed Templates.<a href="http://www.sketchthemes.com/plugins/like-dislike-counter-pro-wordpress-plugin/
" target="_blank">(Pro Version)</a>
* Freedom to Upload Custom Icon Set.<a href="http://www.sketchthemes.com/plugins/like-dislike-counter-pro-wordpress-plugin/
" target="_blank">(Pro Version)</a>
* Different Appearance Settings for Comments & Pages.<a href="http://www.sketchthemes.com/plugins/like-dislike-counter-pro-wordpress-plugin/
" target="_blank">(Pro Version)</a>
* 24 x 7 Premium Support.<a href="http://www.sketchthemes.com/plugins/like-dislike-counter-pro-wordpress-plugin/
" target="_blank">(Pro Version)</a>
* Shortcode to show like dislike buttons within content.<a href="http://www.sketchthemes.com/plugins/like-dislike-counter-pro-wordpress-plugin/
" target="_blank">(Pro Version)</a>
* Enable/Disable for Post Page, Archive Pages(Tags,Authors,Category,Date etc.) and Comments.(Pro Version)
* Display different iconts for Post/Page and Comments.<a href="http://www.sketchthemes.com/plugins/like-dislike-counter-pro-wordpress-plugin/
" target="_blank">(Pro Version)</a>

**PRO Plugin URL: <a href="http://www.sketchthemes.com/plugins/like-dislike-counter-pro-wordpress-plugin/
" target="_blank">Like Dislike Pro Plugin Url</a>**

**PRO Plugin Demo URL: <a href="http://plugins.wpfruits.com/like-dislike/
" target="_blank">Like Dislike Pro Demo</a>**

== Installation ==
1. Upload `like-dislike-counter-for-posts-pages-and-comments` to the `/wp-content/plugins/` directory.
1. Activate the plugin through the 'Plugins' menu in WordPress
2. Activate the plugin via the 'Plugins' menu in WordPress, you'll automatically redirected to plugin admin panel.
3. Plugin settings are located in 'Like Dislike Lite'.

Thanks for using this plugin.

For More Details please visit <a href="http://www.sketchthemes.com/plugins/like-dislike-counter-pro-wordpress-plugin/
" target="_blank">Like Dislike Pro.</a>

== Frequently asked questions ==

= Q: Can this be used for post, page and comments as well. =
A: Yes it can be used for post, page and comments.

For any more questions you can <a href="http://www.sketchthemes.com/helpdesk/index.php?act=tickets&code=open&step=2&department=7"  target="_blank">contact here</a>

== Screenshots ==
1. How to use **Template Code.**
2. Like Dislike Counter **General Settings.**
3. Liked Dislike Counter **Front Appearance.**


== Changelog ==

= Version 1.2.3 =

* Compatible with WordPress latest version(3.9).

= Version 1.2.2 =

* Fixed few plugin admin setting css styles.
* Compatible with WordPress latest version (3.8).

= Version 1.2.1 =

* Upadted text content.
* Changed default options.

= Version 1.2.0 =

* Added admin panel for plugin
* Added code to auto integrate like-dislike button on post/page and comments section.
* Fixed some issues with the WordPress 3.6
* Updated front like dislike button appearance.

= Version 1.1.0 =

* Updated plugin to show down.png in comments too. Earlier it was showing up.png for both like and dislike. 

= Version 1.0.0 =

* Initial release

== Upgrade notice ==
* Upgrade quickly for better performance of plugin.

== Arbitrary section ==